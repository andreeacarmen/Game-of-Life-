/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gol;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import static com.sun.java.accessibility.util.AWTEventMonitor.addMouseListener;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Andreea
 */
public class GameTest {
    
    public GameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }



    /**
     * Test of update method, of class Game.
     * Am setat o configurație initiala a jocului, creand o structura de tip block de 4 celule vii in 
     * coltul din stanga sus.
     * Am verificat daca starea viitoare, dupa update, este cea corespunzatoare
     */
    @Test
    public void testUpdate1() {
        System.out.println("update");
        Game instance = Game.getGame();
        for (int i=0;i<instance.width;i++)
            for (int j=0;j<instance.height;j++){
                 instance.cells[i][j].alive=false;
            }
        int w=2;
        int h=2;
        for(int i=0;i<w;i++)
            for(int j=0;j<h;j++){
                instance.cells[i][j].alive=true;
                }
        instance.go=0;
        instance.update();
        for (int i=0;i<w;i++)
                for (int j=0;j<h;j++){
                    assertEquals(true, instance.cells[i][j].alive);
                }
        for (int i=3;i<instance.width;i++)
            for (int j=3;j<instance.height;j++)
                assertEquals(false, instance.cells[i][j].alive);
        
    }
    
     /**
     * Test of update method, of class Game.
     * Am setat o configurație initiala a jocului, creand o structura de tip block de 4 celule vii in 
     * coltul din dreapta jos.
     * Am verificat daca starea viitoare, dupa update, este cea corespunzatoare
     */
    @Test
    public void testUpdate2() {
        System.out.println("update");
        Game instance = Game.getGame();
        for (int i=0;i<instance.width;i++)
            for (int j=0;j<instance.height;j++){
                 instance.cells[i][j].alive=false;
            }
        int w=instance.width;
        int h=instance.height;
        instance.cells[w-1][h-1].alive=true;
        instance.cells[w-1][h-2].alive=true;
        instance.cells[w-2][h-1].alive=true;
        instance.cells[w-2][h-2].alive=true;
               
        instance.go=0;
        instance.update();
        
        assertEquals(instance.cells[w-1][h-1].alive,true);
        assertEquals(instance.cells[w-1][h-2].alive,true);
        assertEquals(instance.cells[w-2][h-1].alive,true);
        assertEquals(instance.cells[w-2][h-2].alive,true);
        
    }
    
     /**
     * Test of update method, of class Game.
     * Am setat o configurație initiala a jocului, creand o structura de tip block de 4 celule vii in 
     * coltul din dreapta sus.
     * Am verificat daca starea viitoare, dupa update, este cea corespunzatoare
     */
    @Test
    public void testUpdate3() {
        System.out.println("update");
        Game instance = Game.getGame();
        for (int i=0;i<instance.width;i++)
            for (int j=0;j<instance.height;j++){
                 instance.cells[i][j].alive=false;
            }
        int w=instance.width;
        int h=instance.height;
        instance.cells[w-1][0].alive=true;
        instance.cells[w-1][1].alive=true;
        instance.cells[w-2][0].alive=true;
        instance.cells[w-2][1].alive=true;
               
        instance.go=0;
        instance.update();
        
        assertEquals(instance.cells[w-1][0].alive,true);
        assertEquals(instance.cells[w-1][1].alive,true);
        assertEquals(instance.cells[w-2][0].alive,true);
        assertEquals(instance.cells[w-2][1].alive,true);
    }
    
     /**
     * Test of update method, of class Game.
     * Am setat o configurație initiala a jocului, creand o structura de tip block de 4 celule vii in 
     * coltul din stanga jos.
     * Am verificat daca starea viitoare, dupa update, este cea corespunzatoare
     */
    @Test
    public void testUpdate4() {
        System.out.println("update");
        Game instance = Game.getGame();
        for (int i=0;i<instance.width;i++)
            for (int j=0;j<instance.height;j++){
                 instance.cells[i][j].alive=false;
            }
        int w=instance.width;
        int h=instance.height;
        instance.cells[0][h-1].alive=true;
        instance.cells[0][h-2].alive=true;
        instance.cells[1][h-1].alive=true;
        instance.cells[1][h-2].alive=true;
               
        instance.go=0;
        instance.update();
        
        assertEquals(instance.cells[0][h-1].alive,true);
        assertEquals(instance.cells[0][h-2].alive,true);
        assertEquals(instance.cells[1][h-1].alive,true);
        assertEquals(instance.cells[1][h-2].alive,true);
        
    }
    
   /**
     * Test of update method, of class Game.
     * Am setat o configurație initiala a jocului, creand 9 celule vii in mijlocul hartii.
     * Am verificat daca starea viitoare este cea corespunzatoare
     */
    @Test
    public void testUpdate5() {
        System.out.println("update");
        Game g = Game.getGame();
        for (int i=0;i<g.width;i++)
            for (int j=0;j<g.height;j++){
                 g.cells[i][j].alive=false;
            }
        
        g.cells[3][8].alive=true;
        g.cells[3][9].alive=true;
        g.cells[3][10].alive=true;
        g.cells[4][8].alive=true;
        g.cells[4][9].alive=true;
        g.cells[4][10].alive=true;
        g.cells[5][8].alive=true;
        g.cells[5][9].alive=true;
        g.cells[5][10].alive=true;
        g.go=0;
        g.update();
        
        assertEquals(g.cells[3][8].alive,true);
        assertEquals(g.cells[3][9].alive,false);
        assertEquals(g.cells[3][10].alive,true);
        assertEquals(g.cells[4][8].alive,false);
        assertEquals(g.cells[4][9].alive,false);
        assertEquals(g.cells[4][10].alive,false);
        assertEquals(g.cells[5][8].alive,true);
        assertEquals(g.cells[5][0].alive,false);
        assertEquals(g.cells[5][10].alive,true);
        
        assertEquals(g.cells[4][7].alive,true);
        assertEquals(g.cells[2][9].alive,true);
        assertEquals(g.cells[6][9].alive,true);
        assertEquals(g.cells[4][11].alive,true);
    }
   
    /**
     * Test of keyReleased method, of class Game.
     */
    @Test
    public void testKeyReleased() {
        System.out.println("keyReleased");
        Game instance = Game.getGame();
        addKeyListener(instance);
        assertEquals(instance.go,-1);
       
    }

   
    /**
     * Test of mousePressed method, of class Game.
     */
    @Test
    public void testMousePressed() {
        System.out.println("mousePressed");
        Game instance = Game.getGame();
        addMouseListener(instance);
        assertEquals(instance.button,0);
    }

    /**
     * Test of mouseReleased method, of class Game.
     */
    @Test
    public void testMouseReleased() {
        System.out.println("mousePressed");
        Game instance = Game.getGame();
        addMouseListener(instance);
        assertEquals(instance.button,0);
    }
    
}
