/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gol;

import static gol.Dimensions.HEIGHT;
import static gol.Dimensions.WIDTH;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Andreea
 */
public class DimensionsTest {
    
    public DimensionsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of values method, of class Dimensions.
     */
    @Test
    public void testValues() {
        System.out.println("values");
        Dimensions[] expResult = {WIDTH, HEIGHT};
        Dimensions[] result = Dimensions.values();
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of valueOf method, of class Dimensions.
     */
    @Test
    public void testValueOfHeight() {
        System.out.println("valueOf");
        String name = "HEIGHT";
        int expResult = 300;
        Dimensions res = Dimensions.valueOf(name);
        int result = res.value;
        assertEquals(expResult, result);
    }
    
    @Test
    public void testValueOfWidth() {
        System.out.println("valueOf");
        String name = "WIDTH";
        int expResult = 400;
        Dimensions res = Dimensions.valueOf(name);
        int result = res.value;
        assertEquals(expResult, result);
    }
    
}
