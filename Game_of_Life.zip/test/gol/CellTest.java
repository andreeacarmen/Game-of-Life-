/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gol;

import java.awt.Graphics;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Andreea
 */
public class CellTest {
    
    public CellTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getCell method, of class Cell.
     */
    @Test
    public void testGetCell() {
        System.out.println("getCell");
        int x = 3;
        int y = 4;
        Cell expResult = new Cell(x,y);
        Cell result = Cell.getCell(x, y);
        assertEquals(expResult.x, result.x);
        assertEquals(expResult.y, result.y);
        // TODO review the generated test code and remove the default call to fail.
        
    }

}
